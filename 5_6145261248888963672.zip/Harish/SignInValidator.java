import java.util.*;
import java.time.Instant;

import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import helpers.*;

public class SignInValidator implements Validator {

    public boolean isPasswordStrong(String password){
        if(password.length() < 9){
            return false;
        }
        return true;
    }

    public boolean doesUserNameExist(String username){
        try {
            FileReader reader = new FileReader("salt.txt");
            int character;
            String line = "";
            while ((character = reader.read()) != -1) {
                line += (char) character;
                if((char) character == '\n'){
                    if(username.equals(Helpers.extractUsername(line))){
                        return true;
                    }
                    line = "";
                }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return false;
    }

    public boolean checkAccessPeriod(String start, String end){
        SimpleDateFormat frmt = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        try{
            //further format dates
            start = start.replace('/', ' ');
            end = end.replace('/', ' ');
            start = start.split(" ")[1] +" "+ start.split(" ")[2];
            end = end.split(" ")[1] +" "+ end.split(" ")[2];

            Date startDt = frmt.parse(start);
            Date endDt = frmt.parse(end);
    
            long sinceEpochStart = startDt.getTime();
            long sinceEpochEnd = endDt.getTime();
            long now = Instant.now().toEpochMilli();
            if(now < sinceEpochEnd && now > sinceEpochStart){
                return true;
            } else {
                return false;
            }
            
        } catch (ParseException e){
            System.out.println(e.getMessage());
            return false;
        }
        
    }
}