public interface Validator {
   public boolean isPasswordStrong(String password);
   public boolean doesUserNameExist(String username);
   public boolean checkAccessPeriod(String start, String end);
}