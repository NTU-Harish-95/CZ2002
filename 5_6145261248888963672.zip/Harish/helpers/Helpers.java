package helpers;

import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Random;

public class Helpers {
    public static String toHash(String passwordSalt){
        try { 
            MessageDigest md = MessageDigest.getInstance("MD5"); 
            byte[] messageDigest = md.digest(passwordSalt.getBytes()); 
            BigInteger no = new BigInteger(1, messageDigest); 
            String hashtext = no.toString(16); 
            while (hashtext.length() < 32) { 
                hashtext = "0" + hashtext; 
            } 
            return hashtext; 
        }  
        catch (NoSuchAlgorithmException e) { 
            throw new RuntimeException(e); 
        }  
    }

    public static String generateSalt(){
        String salt = "";
        Random r = new Random();
        for(int i=0; i<8; i++){
            String randomDigit = Integer.toString(r.nextInt(10));
            salt += randomDigit;
        }
        return salt;
    }

    public static String getSalt(String username){
        try {
            FileReader reader = new FileReader("salt.txt");
            int character;
            String line = "";
            while ((character = reader.read()) != -1) {
                if((char) character == '\n'){
                    if(username.equals(extractUsername(line))){
                        return extractSalt(line);
                    }
                    line = "";
                }else {
                    line += (char) character;
                }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
            return "";
        }
        return "";
    }

    public static String extractUsername(String line){
        return line.split(":")[0];
    }

    public static String extractSalt(String line){
        return line.split(":")[1];
    }

    public static String extractHash(String line){
        return line.split(":")[1];
    }
    public static String extractUserType(String line){
        return line.split(":")[2];
    }
}