package models;

public class Student {
    private String name;
    private String metricNumber; // unique per student
    private String gender;
    private String nationality;
    private String email;
    private String mobile;

    public Student(String name, String metricNumber, String gender, String nationality, String email, String mobile){
        this.name = name;
        this.metricNumber = metricNumber;
        this.gender = gender;
        this.nationality = nationality;
        this.email = email;
        this.mobile = mobile;
    }

    public String getName() {
        return name;
    }

    public String getMetricNumber() {
        return metricNumber;
    }

    public void printStudent(){
        System.out.println("Name: "+ getName()+", Metric num: "+ getMetricNumber());
    }

    public static Student fromStringToStudent(String line){
        String name = line.split(":")[0];
        String metric = line.split(":")[1];
        String gender = line.split(":")[2];
        String nationality = line.split(":")[3];
        String email = line.split(":")[4];
        String mobile = line.split(":")[5];
        return new Student(name,metric,gender,nationality, email, mobile);
    }
}