package storage;

import java.util.ArrayList;

import models.Course;
import models.Student;

public class Storage {
    public static ArrayList<Student> students = new ArrayList<Student>();
    public static ArrayList<Course> courses = new ArrayList<Course>();
    public static ArrayList<String> settings = new ArrayList<String>();
    public static Student currentStudent;
    
}