package storage;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import models.Course;
import models.Student;

public class StorageManager extends Storage {

    public static void loadCoursesFromFile() {
        courses.clear();
        try {
            FileReader reader = new FileReader("courses.txt");
            int character;
            String line = "";
            while ((character = reader.read()) != -1) {
                if((char) character == '\n'){
                    //line of student information
                    courses.add(Course.fromStringToCourse(line));
                    line = "";
                }else {
                    line += (char) character;
                }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void loadStudentsFromFile() {
        students.clear();
        try {
            FileReader reader = new FileReader("students.txt");
            int character;
            String line = "";
            while ((character = reader.read()) != -1) {
                if((char) character == '\n'){
                    //line of student information
                    students.add(Student.fromStringToStudent(line));
                    line = "";
                }else {
                    line += (char) character;
                }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void loadSettingsFromFile() {
        settings.clear();
        try {
            FileReader reader = new FileReader("settings.txt");
            int character;
            String line = "";
            while ((character = reader.read()) != -1) {
                if((char) character == '\n'){
                    settings.add(line);
                    line = "";
                }else {
                    line += (char) character;
                }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static void writeToFile(String line, String fileName){
        try {
            FileWriter writer = new FileWriter(fileName, true);
            writer.write(line);
            writer.write("\n");
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void overWriteWholeFile(ArrayList<String> lines, String fileName){
        try {
            FileWriter writer = new FileWriter(fileName, false);
            for(int i=0; i< lines.size(); i++){
                writer.write(lines.get(i));
                writer.write("\n");
            }
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }                         
}